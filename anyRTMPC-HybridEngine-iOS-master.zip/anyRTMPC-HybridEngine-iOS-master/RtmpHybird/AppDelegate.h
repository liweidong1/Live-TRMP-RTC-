//
//  AppDelegate.h
//  RtmpHybird
//
//  Created by jianqiangzhang on 16/7/27.
//  Copyright © 2016年 jianqiangzhang. All rights reserved.
//

#import <UIKit/UIKit.h>

static NSString *developerID = @"teameetingtest";
static NSString *token = @"c4cd1ab6c34ada58e622e75e41b46d6d";
static NSString *key = @"OPJXF3xnMqW+7MMTA4tRsZd6L41gnvrPcI25h9JCA4M";
static NSString *appID = @"meetingtest";

#define rtmpServer @"rtmp://192.168.9.232:1935/live"


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

