//
//  GuestViewController.h
//  RTMPCDemo
//
//  Created by jianqiangzhang on 16/7/21.
//  Copyright © 2016年 EricTao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface GuestViewController : UIViewController
@property (nonatomic, strong)LivingItem *livingItem;
@end
