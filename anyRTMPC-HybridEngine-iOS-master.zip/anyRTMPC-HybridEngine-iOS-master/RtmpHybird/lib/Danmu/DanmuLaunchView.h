//
//  DanmuLaunchView.h
//  MessageLivingDemo
//
//  Created by jianqiangzhang on 16/8/2.
//  Copyright © 2016年 jianqiangzhang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DanmuItem.h"

@interface DanmuLaunchView : UIView
- (void)setModel:(DanmuItem*)model;
@end
