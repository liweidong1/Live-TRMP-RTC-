//
//  DanmuItem.h
//  GrounderDemo
//
//  Created by jianqiangzhang on 16/8/2.
//  Copyright © 2016年 贾楠. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DanmuItem : NSObject
@property (nonatomic, strong) NSString *u_nickName; // 名字
@property (nonatomic, strong) NSString *u_userID;  // id
@property (nonatomic, strong) NSString *content;  // 内容
@property (nonatomic, strong) NSString *thumUrl;  // 图
@end
