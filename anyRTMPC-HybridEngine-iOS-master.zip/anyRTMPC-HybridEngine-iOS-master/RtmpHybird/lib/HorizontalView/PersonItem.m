//
//  PersonItem.m
//  RTMPCDemo
//
//  Created by jianqiangzhang on 2016/12/19.
//  Copyright © 2016年 EricTao. All rights reserved.
//

#import "PersonItem.h"

@implementation PersonItem

@end
