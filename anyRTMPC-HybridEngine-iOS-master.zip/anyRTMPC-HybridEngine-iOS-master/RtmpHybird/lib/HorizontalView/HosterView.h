//
//  HosterView.h
//  RTMPCDemo
//
//  Created by jianqiangzhang on 2016/12/19.
//  Copyright © 2016年 EricTao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HosterView : UIView

- (void)setItem:(id)item;

- (void)show;

@end
