//
//  GuestVideoAudioController.h
//  RtmpHybird
//
//  Created by jianqiangzhang on 2017/3/24.
//  Copyright © 2017年 jianqiangzhang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface GuestVideoAudioController : UIViewController

@property (nonatomic, strong)LivingItem *livingItem;

@end
