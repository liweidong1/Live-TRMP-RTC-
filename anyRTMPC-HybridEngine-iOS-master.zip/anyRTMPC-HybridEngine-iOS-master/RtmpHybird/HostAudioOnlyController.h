//
//  HostAudioOnlyController.h
//  RTMPCDemo
//
//  Created by jianqiangzhang on 2016/11/23.
//  Copyright © 2016年 EricTao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HostAudioOnlyController : UIViewController

@property (nonatomic, strong) NSString *livingName;
@property (nonatomic, assign) BOOL isAudioLiving;

@end
