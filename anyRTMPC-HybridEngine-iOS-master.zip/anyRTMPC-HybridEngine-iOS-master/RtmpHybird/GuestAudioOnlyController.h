//
//  GuestAudioOnlyController.h
//  RTMPCDemo
//
//  Created by jianqiangzhang on 2016/11/23.
//  Copyright © 2016年 EricTao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface GuestAudioOnlyController : UIViewController

@property (nonatomic, strong)LivingItem *livingItem;

@end
